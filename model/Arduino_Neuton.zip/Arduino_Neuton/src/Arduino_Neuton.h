/**
 *
 * @defgroup neuton Arduino Neuton TinyML library
 * @{
 *
 * @brief
 *
 */

#ifndef _ARDUINO_NEUTON_H_
#define _ARDUINO_NEUTON_H_

#include "neuton/neuton.h"

#endif /* _ARDUINO_NEUTON_H_ */

/**
 * @}
 */
